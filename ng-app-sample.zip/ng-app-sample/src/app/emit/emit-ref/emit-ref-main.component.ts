import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emit-ref-main',
  template:
  `
  <app-item-ref></app-item-ref>
  `
})
export class EmitRefMainComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
}
